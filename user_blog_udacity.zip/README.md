"Multi User Blog Project for Udacity Full Stack Nanodegree"

url:
https://my-blog-179317.appspot.com/

 **Steps to run
2. Install google app engine
3. Import the application into the launcher.
4. Click on run button
5. Or open command prompt in project folder and run following command: $dev_appserver.py .
6. App will start running on configured port.
